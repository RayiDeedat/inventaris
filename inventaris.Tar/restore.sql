--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.tb_ruang DROP CONSTRAINT tb_ruang_pkey;
ALTER TABLE ONLY public.tb_petugas DROP CONSTRAINT tb_petugas_pkey;
ALTER TABLE ONLY public.tb_peminjaman DROP CONSTRAINT tb_peminjaman_pkey;
ALTER TABLE ONLY public.tb_pegawai DROP CONSTRAINT tb_pegawai_pkey;
ALTER TABLE ONLY public.tb_level DROP CONSTRAINT tb_level_pkey;
ALTER TABLE ONLY public.tb_jenis DROP CONSTRAINT tb_jenis_pkey;
ALTER TABLE ONLY public.tb_inventaris DROP CONSTRAINT tb_inventaris_pkey;
ALTER TABLE ONLY public.tb_detail_pinjaman DROP CONSTRAINT tb_detail_pinjaman_pkey;
DROP TABLE public.tb_ruang;
DROP TABLE public.tb_petugas;
DROP TABLE public.tb_peminjaman;
DROP TABLE public.tb_pegawai;
DROP TABLE public.tb_level;
DROP TABLE public.tb_jenis;
DROP TABLE public.tb_inventaris;
DROP TABLE public.tb_detail_pinjaman;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: tb_detail_pinjaman; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_detail_pinjaman (
    id_detail_pinjaman integer NOT NULL,
    id_inventasris integer,
    jumlah integer
);


ALTER TABLE tb_detail_pinjaman OWNER TO postgres;

--
-- Name: tb_inventaris; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_inventaris (
    id_inventaris integer NOT NULL,
    nama character varying(50),
    kondisi character varying(50),
    keterangan character varying(100),
    jumlah integer,
    id_jenis integer,
    tanggal_register date,
    id_ruang integer,
    kode_inventaris character varying(5),
    id_petugas integer
);


ALTER TABLE tb_inventaris OWNER TO postgres;

--
-- Name: tb_jenis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_jenis (
    id_jenis integer NOT NULL,
    nama_jenis character varying(50),
    kode_jenis character varying(5),
    keterangan character varying(100)
);


ALTER TABLE tb_jenis OWNER TO postgres;

--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_level (
    id_level integer NOT NULL,
    nama_level character varying(50)
);


ALTER TABLE tb_level OWNER TO postgres;

--
-- Name: tb_pegawai; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_pegawai (
    id_pegawai integer NOT NULL,
    nama_pegawai character varying(50),
    nip character varying(50),
    alamat character varying(50)
);


ALTER TABLE tb_pegawai OWNER TO postgres;

--
-- Name: tb_peminjaman; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_peminjaman (
    id_peminjaman integer NOT NULL,
    tanggal_pinjam date,
    tanggal_kembali date,
    status_peminjaman character varying(20),
    id_pegawai integer
);


ALTER TABLE tb_peminjaman OWNER TO postgres;

--
-- Name: tb_petugas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_petugas (
    id_petugas integer NOT NULL,
    username character varying(50),
    password character varying(50),
    nama_petugas character varying(50),
    id_level integer
);


ALTER TABLE tb_petugas OWNER TO postgres;

--
-- Name: tb_ruang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_ruang (
    id_ruang integer NOT NULL,
    nama_ruang character varying(50),
    kode_ruang character varying(5),
    keterangan character varying(100)
);


ALTER TABLE tb_ruang OWNER TO postgres;

--
-- Data for Name: tb_detail_pinjaman; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_detail_pinjaman (id_detail_pinjaman, id_inventasris, jumlah) FROM stdin;
\.
COPY tb_detail_pinjaman (id_detail_pinjaman, id_inventasris, jumlah) FROM '$$PATH$$/2837.dat';

--
-- Data for Name: tb_inventaris; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_inventaris (id_inventaris, nama, kondisi, keterangan, jumlah, id_jenis, tanggal_register, id_ruang, kode_inventaris, id_petugas) FROM stdin;
\.
COPY tb_inventaris (id_inventaris, nama, kondisi, keterangan, jumlah, id_jenis, tanggal_register, id_ruang, kode_inventaris, id_petugas) FROM '$$PATH$$/2835.dat';

--
-- Data for Name: tb_jenis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_jenis (id_jenis, nama_jenis, kode_jenis, keterangan) FROM stdin;
\.
COPY tb_jenis (id_jenis, nama_jenis, kode_jenis, keterangan) FROM '$$PATH$$/2833.dat';

--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_level (id_level, nama_level) FROM stdin;
\.
COPY tb_level (id_level, nama_level) FROM '$$PATH$$/2838.dat';

--
-- Data for Name: tb_pegawai; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_pegawai (id_pegawai, nama_pegawai, nip, alamat) FROM stdin;
\.
COPY tb_pegawai (id_pegawai, nama_pegawai, nip, alamat) FROM '$$PATH$$/2840.dat';

--
-- Data for Name: tb_peminjaman; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_peminjaman (id_peminjaman, tanggal_pinjam, tanggal_kembali, status_peminjaman, id_pegawai) FROM stdin;
\.
COPY tb_peminjaman (id_peminjaman, tanggal_pinjam, tanggal_kembali, status_peminjaman, id_pegawai) FROM '$$PATH$$/2839.dat';

--
-- Data for Name: tb_petugas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_petugas (id_petugas, username, password, nama_petugas, id_level) FROM stdin;
\.
COPY tb_petugas (id_petugas, username, password, nama_petugas, id_level) FROM '$$PATH$$/2836.dat';

--
-- Data for Name: tb_ruang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_ruang (id_ruang, nama_ruang, kode_ruang, keterangan) FROM stdin;
\.
COPY tb_ruang (id_ruang, nama_ruang, kode_ruang, keterangan) FROM '$$PATH$$/2834.dat';

--
-- Name: tb_detail_pinjaman tb_detail_pinjaman_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_detail_pinjaman
    ADD CONSTRAINT tb_detail_pinjaman_pkey PRIMARY KEY (id_detail_pinjaman);


--
-- Name: tb_inventaris tb_inventaris_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_inventaris
    ADD CONSTRAINT tb_inventaris_pkey PRIMARY KEY (id_inventaris);


--
-- Name: tb_jenis tb_jenis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_jenis
    ADD CONSTRAINT tb_jenis_pkey PRIMARY KEY (id_jenis);


--
-- Name: tb_level tb_level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level
    ADD CONSTRAINT tb_level_pkey PRIMARY KEY (id_level);


--
-- Name: tb_pegawai tb_pegawai_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_pegawai
    ADD CONSTRAINT tb_pegawai_pkey PRIMARY KEY (id_pegawai);


--
-- Name: tb_peminjaman tb_peminjaman_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_peminjaman
    ADD CONSTRAINT tb_peminjaman_pkey PRIMARY KEY (id_peminjaman);


--
-- Name: tb_petugas tb_petugas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_petugas
    ADD CONSTRAINT tb_petugas_pkey PRIMARY KEY (id_petugas);


--
-- Name: tb_ruang tb_ruang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_ruang
    ADD CONSTRAINT tb_ruang_pkey PRIMARY KEY (id_ruang);


--
-- PostgreSQL database dump complete
--

